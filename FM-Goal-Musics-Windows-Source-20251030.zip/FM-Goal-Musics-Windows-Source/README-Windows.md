# FM Goal Musics - Windows Installation

## 🚀 SUPER EASY - One-Click Installation!

### Option 1: PowerShell Installer (Recommended)
1. Right-click `INSTALL-WINDOWS.ps1`
2. Select "Run with PowerShell"
3. Follow the prompts - everything is automatic!

### Option 2: Batch Installer
1. Double-click `INSTALL-WINDOWS.bat`
2. Follow the prompts in the command window

### What the installer does automatically:
- ✅ Downloads and installs Rust (if needed)
- ✅ Builds the application (10-15 minutes)
- ✅ Creates ready-to-use executable
- ✅ Includes all OCR functionality
- ✅ No technical knowledge required!

## 📦 What You Get After Installation:
- `build\windows\fm-goal-musics-gui.exe` - Main application
- Self-contained OCR (no external installation needed)
- Portable ZIP file to share with friends

## ⚙️ Manual Installation (Advanced)

If you prefer manual setup:

### Prerequisites:
- Windows 10 or 11
- Internet connection (one-time setup)

### Installation Steps:

1. **Install Rust** (one-time setup):
   - Download and run: https://rustup.rs/
   - Restart command prompt after installation

2. **Build the application**:
   ```batch
   build_windows.bat
   ```

3. **Run the app**:
   - Extract the generated ZIP file
   - Double-click `fm-goal-musics-gui.exe`

### Need Help?
- Check BUILD.md for detailed instructions
- All features work out of the box

Enjoy your goal celebration music! 🎵⚽
