# FM Goal Musics - Windows Installation

## Quick Start (No Rust knowledge needed!)

### Prerequisites:
- Windows 10 or 11
- Internet connection (one-time setup)

### Installation Steps:

1. **Install Rust** (one-time setup):
   - Download and run: https://rustup.rs/
   - Restart command prompt after installation

2. **Build the application**:
   ```batch
   build_windows.bat
   ```

3. **Run the app**:
   - Extract the generated ZIP file
   - Double-click `fm-goal-musics-gui.exe`

### What You Get:
- Self-contained Windows application
- No external dependencies needed
- Includes OCR functionality
- Portable - no installation required

### Need Help?
- Check BUILD.md for detailed instructions
- All features work out of the box

Enjoy your goal celebration music! 🎵⚽
